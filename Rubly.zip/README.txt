Hi this is my Offical Prank Malware 
This Malware isn´t harmful.
It will block our sreen and you have to type a 
Passwort to unlock.
If you forgot the Passwort restart you Computer.
The Malware will NOT encrypt files.
So have fun with this Malware and Prank your friends.



Here is the Passwort: BCPKX-GXW2B-7MGWJ-DYQWY-8YMJR


Copyright 2019 MALTEH

Follow me on YouTube: 
https://www.youtube.com/channel/UCWAV6szdLHHGZr9XoqLAeNA


If you want to download it go to:

http://bit.ly/Rubly